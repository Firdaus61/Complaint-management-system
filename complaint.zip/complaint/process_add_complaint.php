<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Establish database connection
    $host = "localhost"; // Change to your database host
    $username = "root"; // Change to your database username
    $password = ""; // Change to your database password
    $database = "complaint"; // Change to your database name

   // Establish database connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO complaints (name, email, student_id, phone_number, programmed_code, division_unit, subject, message, attachment, priority) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssss", $name, $email, $student_id, $phone_number, $programmed_code, $division_unit, $subject, $message, $attachment, $priority);

    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $student_id = $_POST['student_id'];
    $phone_number = $_POST['phone_number'];
    $programmed_code = $_POST['programmed_code'];
    $division_unit = $_POST['division_unit'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];
    $attachment = $_FILES['attachment']['name']; // File name
    $priority = $_POST['priority'];

    // Upload attachment file
    $target_directory = "attachments/"; // Change to your desired directory
    $target_file = $target_directory . basename($_FILES['attachment']['name']);
    move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file);

    // Execute the SQL statement
    $stmt->execute();

    // Close statement and database connection
    $stmt->close();
    $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Submitted</title>
    <link rel="stylesheet" href="styles_process_complaint.css"> <!-- Link to your CSS file -->
</head>
<body>
    <div class="container">
        <h1>Complaint Submitted</h1>
        <p>Your complaint has been successfully submitted.</p>
        
        <!-- Button to go back to index.php -->
        <a href="index.php" class="back-button">Back to Home</a>
    </div>
</body>
</html>
<?php
} else {
    // If the form is not submitted, redirect back to the form page
    header("Location: add_complaint.php");
    exit();
}
?>
