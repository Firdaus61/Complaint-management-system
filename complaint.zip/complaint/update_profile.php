<?php
// Start session to access user session data
session_start();

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    // If not logged in, redirect to the sign-in page
    header("Location: signin.php?error=Please log in to update your profile.");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "complaint";

    // Create a connection to the database
    $conn = mysqli_connect($host, $username, $password, $database);

    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get form data
    $new_username = $_POST["new_username"];
    $new_password = $_POST["new_password"];
    $new_address = $_POST["new_address"];

    // Escape special characters to prevent SQL injection
    $new_username = mysqli_real_escape_string($conn, $new_username);
    $new_password = mysqli_real_escape_string($conn, $new_password);
    $new_address = mysqli_real_escape_string($conn, $new_address);

    // Fetch user email from session
    $user_email = $_SESSION["email"];

    // Update user profile in the database
    $sql = "UPDATE users SET username='$new_username', password='$new_password', address='$new_address' WHERE email='$user_email'";

    if (mysqli_query($conn, $sql)) {
        // Profile updated successfully
        header("Location: profile.php?success=Profile updated successfully.");
        exit();
    } else {
        // Error updating profile
        header("Location: profile.php?error=Error updating profile. Please try again.");
        exit();
    }

    // Close database connection
    mysqli_close($conn);
} else {
    // If form is not submitted, redirect to the profile page
    header("Location: profile.php");
    exit();
}
?>
