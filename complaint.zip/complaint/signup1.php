<?php

// Database connection parameters
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "complaint"; 

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup-submit"])) {
    // Get the form data and sanitize input
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    $confirm_password = mysqli_real_escape_string($conn, $_POST["confirm_password"]);
    $number = mysqli_real_escape_string($conn, $_POST["number"]);
    $address = mysqli_real_escape_string($conn, $_POST["address"]);
    $other_address = ""; // Initialize other_address variable

    if ($address === 'Other') {
        $other_address = mysqli_real_escape_string($conn, $_POST["other_address"]);
    }

    // Validate input
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        header("Location: signup.php?error=Please fill in all fields");
        exit();
    } elseif ($password !== $confirm_password) {
        header("Location: signup.php?error=Passwords do not match");
        exit();
    } elseif (!validatePassword($password)) {
        header("Location: signup.php?error=Password require 1 uppercase, 1 lowercase, 1 unique symbol, 1 number");
        exit();
    }

    // Check if email already exists
    $email_check_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $result = mysqli_query($conn, $email_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) { // If email exists
        header("Location: signup.php?error=Email already exists");
        exit();
    }

    // Check if username already exists
    $username_check_query = "SELECT * FROM users WHERE username='$username' LIMIT 1";
    $result = mysqli_query($conn, $username_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) { // If username exists
        header("Location: signup.php?error=Username already exists");
        exit();
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert user data into the database
    $sql = "INSERT INTO users (username, email, password, number, address) VALUES ('$username', '$email', '$hashed_password', '$number', ";
    if ($address === 'Other') {
        $sql .= "'$other_address'";
    } else {
        $sql .= "'$address'";
    }
    $sql .= ")";
    if (mysqli_query($conn, $sql)) {
        // Registration successful, redirect to sign-in page
        header("Location: signin.php");
        exit();
    } else {
        // Error inserting user into the database
        header("Location: signup.php?error=Registration failed");
        exit();
    }
} else {
    // Redirect back to the sign-up page if accessed directly
    header("Location: signup.php");
    exit();
}

// Function to validate password complexity
function validatePassword($password) {
    // Define a regex pattern for password validation
    $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[_\W])[A-Za-z\d_\W]{8,}$/';

    // Check if the password matches the pattern
    return preg_match($pattern, $password);
}
?>
