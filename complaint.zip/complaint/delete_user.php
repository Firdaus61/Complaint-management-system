<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete User</title>
    <style>
        /* Styles for delete_user.php */

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .title {
            text-align: center;
            margin-bottom: 20px;
        }

        .error-message {
            color: #dc3545;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .success-message {
            color: #28a745;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="title">Delete User</h2>
    <?php
    // Establish database connection
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "complaint";

    $conn = mysqli_connect($host, $username, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Check if the user ID is provided in the URL
    if (isset($_GET['id']) && !empty($_GET['id'])) {
        $user_id = $_GET['id'];

        // Delete the user from the database
        $delete_sql = "DELETE FROM users WHERE id = $user_id";
        if (mysqli_query($conn, $delete_sql)) {
            echo "<p class='success-message'>User deleted successfully.</p>";
        } else {
            echo "<p class='error-message'>Error deleting user: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p class='error-message'>User ID not provided.</p>";
    }

    // Close database connection
    mysqli_close($conn);
    ?>
    <button class="button" onclick="window.location.href='admin.php'">Back to Admin Dashboard</button>
</div>
</body>
</html>
