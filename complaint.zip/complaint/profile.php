<?php
// Start session to access user session data
session_start();

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    // If not logged in, redirect to the sign-in page
    header("Location: signin.php?error=Please log in to view your profile.");
    exit();
}

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$database = "complaint";

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user data based on the email stored in the session
$user_email = $_SESSION["email"];
$sql = "SELECT * FROM users WHERE email = '$user_email'";
$result = mysqli_query($conn, $sql);

// Check if user data exists
if (mysqli_num_rows($result) > 0) {
    // Fetch user information
    $row = mysqli_fetch_assoc($result);
    $username = $row["username"];
    $email = $row["email"];
    $number = $row["number"];
    $address = $row["address"];

    // Close the database connection
    mysqli_close($conn);
} else {
    // If no user data found, display an error message
    $username = "Unknown";
    $email = "Unknown";
    $number = "Unknown";
    $address = "Unknown";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link rel="stylesheet" href="styles_profile.css">
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    margin: 80px auto;
    padding: 40px;
    max-width: 600px;
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

.edit-form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input[type="text"],
input[type="password"],
select {
    width: 100%;
    padding: 8px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type="submit"] {
    background-color: #007bff;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

#new_address {
    display: none;
}

</style>
<body>
    <div class="container">
        <h1>Edit Profile</h1>
        <!-- Edit form -->
        <div class="edit-form">
            <form action="update_profile.php" method="post">
                <label for="new_username">New Username:</label>
                <input type="text" id="new_username" name="new_username" value="<?php echo $username; ?>" required>
                
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required>

                <!-- Address dropdown button -->
                <select name="address" id="address" onchange="selectAddress()">
                    <option value="Mr.">Mr.</option>
                    <option value="Ms.">Ms.</option>
                    <option value="Mrs.">Mrs.</option>
                    <option value="Dr.">Dr.</option>
                    <option value="Prof.">Prof.</option>
                    <option value="Other">Other</option>
                </select>

                <!-- Hidden input field for other address -->
                <input type="text" id="new_address" name="new_address" value="<?php echo $address; ?>" style="display: none;">
                
                <input type="submit" value="Update">
            </form>
        </div>
    </div>

    <script>
        // JavaScript function to show/hide the other address input field
        function selectAddress() {
            var addressSelect = document.getElementById("address");
            var otherAddressInput = document.getElementById("new_address");
            if (addressSelect.value === "Other") {
                otherAddressInput.style.display = "block";
                otherAddressInput.setAttribute("required", "required");
            } else {
                otherAddressInput.style.display = "none";
                otherAddressInput.removeAttribute("required");
                otherAddressInput.value = addressSelect.value;
            }
        }
    </script>
</body>
</html>
