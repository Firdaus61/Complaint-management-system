<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Complaint</title>
    <link rel="stylesheet" href="styles_view_complaint3.css"> <!-- Link to your CSS file -->
</head>
<body>
<?php
// Define database connection parameters
$host = "localhost"; // Change to your database host
$username = "root"; // Change to your database username
$password = ""; // Change to your database password
$database = "complaint"; // Change to your database name

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form is submitted, process the update status request

    // Check if complaint ID is provided in the form
    if (isset($_POST['complaint_id'])) {
        // Establish database connection
        $conn = mysqli_connect($host, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Fetch complaint details from the form
        $complaint_id = $_POST['complaint_id'];
        $status = $_POST['status'];

        // Update the status in the database
        $sql = "UPDATE complaints SET status = '$status' WHERE id = $complaint_id";

        if (mysqli_query($conn, $sql)) {
            echo "Status updated successfully.";
        } else {
            echo "Error updating status: " . mysqli_error($conn);
        }

        // Close database connection
        mysqli_close($conn);
    } else {
        echo "Complaint ID not provided.";
    }
}

// Fetch complaint details from the database
if (isset($_GET['id'])) {
    $complaint_id = $_GET['id'];
    
    // Establish database connection
    $conn = mysqli_connect($host, $username, $password, $database);
    
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    // Fetch complaint details from the database
    $sql = "SELECT * FROM complaints WHERE id = $complaint_id";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $complaint = mysqli_fetch_assoc($result);
        // Display complaint details
        ?>
        <h2>1. User Information</h2>
        <p><strong>Name:</strong> <?php echo $complaint['name']; ?></p>
        <p><strong>Email:</strong> <?php echo $complaint['email']; ?></p>
        <p><strong>Student ID:</strong> <?php echo $complaint['student_id']; ?></p>
        <p><strong>Phone Number:</strong> <?php echo $complaint['phone_number']; ?></p>
        <p><strong>Programmed Code:</strong> <?php echo $complaint['programmed_code']; ?></p>

        <h2>2. Complaint Information</h2>
        <p><strong>Division/Unit:</strong> <?php echo $complaint['division_unit']; ?></p>

        <h2>3. Subject</h2>
        <p><strong>Subject:</strong> <?php echo $complaint['subject']; ?></p>
        <p><strong>Message:</strong> <?php echo $complaint['message']; ?></p>
        <p><strong>Attachment:</strong> <a href="<?php echo $complaint['attachment']; ?>">Download Attachment</a></p>
        <?php
    } else {
        echo "Complaint not found.";
    }
    
    // Close database connection
    mysqli_close($conn);
} else {
    echo "Complaint ID not provided.";
}
?>

<!-- HTML form for updating complaint status -->
<form method="post">
    <input type="hidden" name="complaint_id" value="<?php echo $complaint_id; ?>">
    <h2>Update Status</h2>
    <label for="status">Status:</label>
    <select name="status" id="status" onchange="toggleAdminReply(this)">
        <option value="pending" <?php if (isset($complaint['status']) && $complaint['status'] === 'pending') echo 'selected'; ?>>Pending</option>
        <option value="in progress" <?php if (isset($complaint['status']) && $complaint['status'] === 'in progress') echo 'selected'; ?>>In Progress</option>
        <option value="completed" <?php if (isset($complaint['status']) && $complaint['status'] === 'completed') echo 'selected'; ?>>Completed</option>
    </select>
    <button type="submit">Update Status</button>
</form>

<!-- Box for Admin Reply -->
<div class="admin-reply-box" id="admin-reply-box" style="display: none;">
    <h2>Admin Reply</h2>
    <form action="save_reply.php" method="post">
        <input type="hidden" name="complaint_id" value="<?php echo $complaint_id; ?>">
        <textarea name="admin_reply" id="admin_reply" cols="30" rows="5" placeholder="Enter your reply here"></textarea>
        <button type="submit">Save Reply</button>
    </form>
</div>


<script>
    function goToAdmin() {
        window.location.href = 'admin.php';
    }

    function toggleAdminReply(statusSelect) {
        var adminReplyBox = document.getElementById("admin-reply-box");
        adminReplyBox.style.display = (statusSelect.value === "completed") ? "block" : "none";
    }
</script>

</body>
</html>
