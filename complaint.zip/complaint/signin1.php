<?php
// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$database = "complaint";

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Start session
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signin-submit"])) {
    // Get the form data
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $password = $_POST["password"];

    // Retrieve regular user information from the database based on the provided email
    $sql_user = "SELECT id, username, email, password FROM users WHERE email = '$email'";
    $result_user = mysqli_query($conn, $sql_user);

    if ($result_user && mysqli_num_rows($result_user) > 0) {
        $user = mysqli_fetch_assoc($result_user);

        // Verify password for regular user
        if (password_verify($password, $user["password"])) {
            // Password is correct, set up user session
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];
            $_SESSION["email"] = $user["email"];

            // Redirect to dashboard or any other page for regular user
            mysqli_close($conn);
            header("Location: index.php");
            exit();
        } else {
            // Incorrect password for regular user
            mysqli_close($conn);
            header("Location: signin.php?error=Incorrect password");
            exit();
        }
    }

    // Retrieve admin information from the database based on the provided email
    $sql_admin = "SELECT id, email, password FROM admins WHERE email = '$email'";
    $result_admin = mysqli_query($conn, $sql_admin);

    if ($result_admin && mysqli_num_rows($result_admin) > 0) {
        $admin = mysqli_fetch_assoc($result_admin);

        // Verify password for admin
        if ($password === $admin["password"]) { // Change this to use hashed passwords
            // Password is correct, set up admin session
            $_SESSION["admin_id"] = $admin["id"];
            $_SESSION["admin_email"] = $admin["email"];

            // Redirect to admin dashboard or any other admin page
            mysqli_close($conn);
            header("Location: admin.php");
            exit();
        }
    }

    // If neither regular user nor admin found, redirect back to sign-in page with error
    mysqli_close($conn);
    header("Location: signin.php?error=Invalid email or password");
    exit();
} else {
    // Redirect back to the sign-in page if someone tries to access this page directly
    header("Location: signin.php");
    exit();
}

