
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Sign In</title>
    <link rel="stylesheet" href="styles2.css"> 
</head>
<body>
    <div class="container">
        <h2>User Sign In</h2>
        <form action="signin1.php" method="post">
            <div class="error"><?php if(isset($_GET['error'])) echo $_GET['error']; ?></div>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" name="signin-submit" value="Sign In">
        </form>
        <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
    </div>
</body>
</html>
