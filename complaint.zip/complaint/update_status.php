<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Complaint</title>
    <style>
        /* Your CSS styles here */
        /* For example: */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px; 
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if complaint ID and status are provided
    if (isset($_POST['complaint_id']) && isset($_POST['status'])) {
        // Sanitize input
        $complaint_id = $_POST['complaint_id'];
        $status = $_POST['status'];

        // Establish database connection
        $host = "localhost"; // Change to your database host
        $username = "root"; // Change to your database username
        $password = ""; // Change to your database password
        $database = "complaint"; // Change to your database name

        $conn = mysqli_connect($host, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Update status in the database
        $sql = "UPDATE complaints SET status='$status' WHERE id=$complaint_id";

        if (mysqli_query($conn, $sql)) {
            echo "Status updated successfully.";
        } else {
            echo "Error updating status: " . mysqli_error($conn);
        }

        // Close database connection
        mysqli_close($conn);
    } else {
        echo "Complaint ID or status not provided.";
    }
} else {
    echo "Invalid request.";
}
?>

<button onclick="goBack()">Back</button>

<script>
    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
