<?php
// Check if the complaint ID is provided in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Database connection parameters
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "complaint";

    // Create a connection to the database
    $conn = mysqli_connect($host, $username, $password, $database);

    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Get the complaint ID from the URL parameter
    $complaint_id = $_GET['id'];

    // Prepare the SQL statement to delete the complaint
    $sql = "DELETE FROM complaints WHERE id = $complaint_id";

    // Execute the SQL statement
    if (mysqli_query($conn, $sql)) {
        // Complaint deleted successfully, redirect back to the dashboard
        mysqli_close($conn);
        header("Location: index.php");
        exit();
    } else {
        // Error occurred while deleting the complaint
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
} else {
    // If the complaint ID is not provided in the URL, redirect back to the dashboard
    header("Location: index.php");
    exit();
}
?>
