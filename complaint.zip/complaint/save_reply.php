<?php
// Check if the form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are present
    if (isset($_POST['complaint_id']) && isset($_POST['admin_reply'])) {
        // Establish database connection
        $host = "localhost"; // Change to your database host
        $username = "root"; // Change to your database username
        $password = ""; // Change to your database password
        $database = "complaint"; // Change to your database name

        $conn = mysqli_connect($host, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Fetch admin reply details from the form
        $complaint_id = $_POST['complaint_id'];
        $admin_reply = $_POST['admin_reply'];

        // Insert admin reply into the database
        $sql = "INSERT INTO admin_replies (complaint_id, admin_reply) VALUES ('$complaint_id', '$admin_reply')";

        if (mysqli_query($conn, $sql)) {
            echo "Admin reply saved successfully.";
        } else {
            echo "Error saving admin reply: " . mysqli_error($conn);
        }

        // Close database connection
        mysqli_close($conn);
    } else {
        echo "Form data incomplete.";
    }
} else {
    echo "Invalid request.";
}
?>
