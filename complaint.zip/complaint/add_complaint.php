<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Complaint</title>
    <link rel="stylesheet" href="styles_add_complaint.css"> <!-- Link to your CSS file -->
</head>
<body>
<header>
    <div class="logo">
        <img src="UPTM.png" alt="Admin Logo">
    </div>
</header>
<button class="back-button" onclick="goBack()">Back</button>
<div class="container">
    <h1>Add Complaint</h1>
    <form action="process_add_complaint.php" method="post" enctype="multipart/form-data">
        <h2>User Information</h2>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        <label for="student_id">Student ID:</label>
        <input type="text" id="student_id" name="student_id" required>
        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number">

        <h2>Complaint Information</h2>
        <label for="programmed_code">Programmed Code:</label>
        <select id="programmed_code" name="programmed_code" required>
            <?php
            // Establish database connection
            $host = "localhost";
            $username = "root";
            $password = "";
            $database = "complaint";
            $conn = mysqli_connect($host, $username, $password, $database);

            // Fetch programmed codes from the database
            $sql_programmed_codes = "SELECT id, code FROM programmed_codes";
            $result_programmed_codes = mysqli_query($conn, $sql_programmed_codes);

            // Check if there are programmed codes
            if (mysqli_num_rows($result_programmed_codes) > 0) {
                // Output options for each programmed code
                while ($row = mysqli_fetch_assoc($result_programmed_codes)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['code'] . "</option>";
                }
            }
            ?>
        </select>

        <label for="division_unit">Division/Unit:</label>
        <select id="division_unit" name="division_unit">
            <?php
             // Establish database connection
             $host = "localhost";
             $username = "root";
             $password = "";
             $database = "complaint";
             $conn = mysqli_connect($host, $username, $password, $database);
             
            // Fetch division units from the database
            $sql_division_units = "SELECT id, name FROM division_unit";
            $result_division_units = mysqli_query($conn, $sql_division_units);

            // Check if there are division units
            if (mysqli_num_rows($result_division_units) > 0) {
                // Output options for each division unit
                while ($row = mysqli_fetch_assoc($result_division_units)) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
            }
            ?>
        </select>

        <label for="subject">Subject:</label>
        <input type="text" id="subject" name="subject" required>
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea>
        <label for="attachment">Attachment:</label>
        <input type="file" id="attachment" name="attachment">
        
        <h2>Priority</h2>
        <select name="priority" id="priority">
            <option value="low">Low</option>
            <option value="medium" selected>Medium</option>
            <option value="high">High</option>
        </select>

        <button type="submit">Submit</button>
    </form>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
