<?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    // If not logged in, redirect to the sign-in page
    header("Location: signin.php?error=Please log in to edit your complaints.");
    exit();
}

// Check if complaint ID is provided
if (!isset($_GET["id"])) {
    // If complaint ID is not provided, redirect back to the complaint page
    header("Location: index.php");
    exit();
}

// Get complaint ID from the URL parameter
$complaint_id = $_GET["id"];

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$database = "complaint";

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch the complaint details based on the complaint ID
$sql = "SELECT * FROM complaints WHERE id = '$complaint_id' AND email = '{$_SESSION['email']}'";
$result = mysqli_query($conn, $sql);

// Check if the complaint exists
if (mysqli_num_rows($result) == 0) {
    // If the complaint does not exist or does not belong to the user, redirect back to the complaint page
    header("Location: index.php");
    exit();
}

// Fetch complaint details
$complaint = mysqli_fetch_assoc($result);

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit-submit"])) {
    // Retrieve updated complaint details from the form
    $new_division = $_POST["division"];
    $new_subject = $_POST["subject"];
    $new_message = $_POST["message"];

    // Check if a new attachment is uploaded
    if ($_FILES['attachment']['name']) {
        // Upload new attachment file
        $target_directory = "attachments/"; // Change to your desired directory
        $target_file = $target_directory . basename($_FILES['attachment']['name']);
        move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file);

        // Update attachment in the database
        $new_attachment = $_FILES['attachment']['name'];
        $sql_update = "UPDATE complaints SET division_unit = '$new_division', subject = '$new_subject', message = '$new_message', attachment = '$new_attachment' WHERE id = '$complaint_id'";
    } else {
        // If no new attachment is uploaded, only update the division, subject, and message
        $sql_update = "UPDATE complaints SET division_unit = '$new_division', subject = '$new_subject', message = '$new_message' WHERE id = '$complaint_id'";
    }

    // Execute the update query
    $result_update = mysqli_query($conn, $sql_update);

    // Check if the update was successful
    if ($result_update) {
        // Redirect back to the complaint page with a success message
        header("Location: index.php?success=Complaint updated successfully");
        exit();
    } else {
        // Redirect back to the complaint page with an error message
        header("Location: index.php?error=Failed to update complaint");
        exit();
    }
}

// Close database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Complaint</title>
    <link rel="stylesheet" href="edit_complaint.css"> <!-- Link to your CSS file -->
</head>
<body>
    <header>
        <div class="logo">
            <img src="UPTM.png" alt="Admin Logo">
        </div>
    </header>
    <div class="container">
        <h1>Edit Complaint</h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <label for="division">Division/Unit:</label>
            <input type="text" id="division" name="division" value="<?php echo $complaint['division_unit']; ?>" required><br><br>
            
            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" value="<?php echo $complaint['subject']; ?>" required><br><br>
            
            <label for="message">Message:</label><br>
            <textarea id="message" name="message" rows="4" cols="50" required><?php echo $complaint['message']; ?></textarea><br><br>
            
            <label for="attachment">Attachment:</label>
            <input type="file" id="attachment" name="attachment"><br><br>
            
            <button type="submit" name="edit-submit">Update</button>
        </form>
    </div>
</body>
</html>
