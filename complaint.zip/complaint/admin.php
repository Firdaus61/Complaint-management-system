<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles_admin2.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="UPTM.png" alt="Admin Logo"> 
        </div>
        <div class="logout">
        <button onclick="window.location.href='signin.php'">logout</button>
    </div>
    </header>
    <nav>
        <button class="tablink" onclick="openPage('manageComplaintsSection', this)">Manage Complaints</button>
        <button class="tablink" onclick="openPage('manageComplaintFormsSection', this)">Manage Complaint Forms</button>
        <button class="tablink" onclick="openPage('manageUsersSection', this)">Manage Users</button>
        <button class="tablink" onclick="openPage('adminGuide', this)">Admin Guide</button>
        
    </nav>

    <div class="content">
        
        <div id="manageComplaintsSection" class="tabcontent">
         
            <h2>Manage Complaints</h2>
            <?php
    // Establish database connection
    $host = "localhost"; 
    $username = "root"; 
    $password = ""; 
    $database = "complaint"; 

    $conn = mysqli_connect($host, $username, $password, $database);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch complaints count from the database for each status
    $sql_pending = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'Pending'";
    $sql_in_progress = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'In Progress'";
    $sql_completed = "SELECT COUNT(*) AS count FROM complaints WHERE status = 'Completed'";

    $result_pending = mysqli_query($conn, $sql_pending);
    $result_in_progress = mysqli_query($conn, $sql_in_progress);
    $result_completed = mysqli_query($conn, $sql_completed);

    // Check if there are counts for each status
    if (mysqli_num_rows($result_pending) > 0 && mysqli_num_rows($result_in_progress) > 0 && mysqli_num_rows($result_completed) > 0) {
        $row_pending = mysqli_fetch_assoc($result_pending);
        $row_in_progress = mysqli_fetch_assoc($result_in_progress);
        $row_completed = mysqli_fetch_assoc($result_completed);

        // Display counts for each status
        echo "<div class='status-counts'>";
        echo "<div class='status-count'>";
        echo "<h3>Pending</h3>";
        echo "<p>" . $row_pending['count'] . "</p>";
        echo "</div>";
        echo "<div class='status-count'>";
        echo "<h3>In Progress</h3>";
        echo "<p>" . $row_in_progress['count'] . "</p>";
        echo "</div>";
        echo "<div class='status-count'>";
        echo "<h3>Completed</h3>";
        echo "<p>" . $row_completed['count'] . "</p>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "Error fetching complaint counts.";
    }

    // Close database connection
    mysqli_close($conn);
    ?>
            <?php
            // Establish database connection
            $host = "localhost"; 
            $username = "root"; 
            $password = ""; 
            $database = "complaint"; 

            $conn = mysqli_connect($host, $username, $password, $database);

            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Fetch complaints from the database
            $sql = "SELECT * FROM complaints";
            $result = mysqli_query($conn, $sql);

            // Check if there are complaints
            if (mysqli_num_rows($result) > 0) {
                // Display complaints in a table
                echo "<table>";
                echo "<tr><th>Name</th><th>Email</th><th>Student ID</th><th>Subject</th><th>created_at</th><th>Action</th></tr>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['student_id'] . "</td>";
                    echo "<td>" . $row['subject'] . "</td>";
                    echo "<td>" . $row['created_at'] . "</td>";
                    echo "<td><a href='view_complaint.php?id=" . $row['id'] . "' class='see-details-link'>See Details</a></td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No complaints found.";
            }

            // Close database connection
            mysqli_close($conn);
            ?>
        </div>

        <div id="manageComplaintFormsSection" class="tabcontent">
             <!-- Display existing divisions/units -->
    <h2>Divisions/Units</h2>
    <?php
     // Establish database connection
     $host = "localhost"; 
     $username = "root"; 
     $password = ""; 
     $database = "complaint"; 

     $conn = mysqli_connect($host, $username, $password, $database);

     if (!$conn) {
         die("Connection failed: " . mysqli_connect_error());
     }

    $division_unit_query = "SELECT * FROM division_unit";
    $division_unit_result = mysqli_query($conn, $division_unit_query);

    if (mysqli_num_rows($division_unit_result) > 0) {
        echo "<ul>";
        while ($division_unit_row = mysqli_fetch_assoc($division_unit_result)) {
            echo "<li>" . $division_unit_row['name'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "No divisions/units found.";
    }
    ?>

    <!-- Display existing programmed codes -->
    <h2>Programmed Codes</h2>
    <?php
    $programmed_code_query = "SELECT * FROM programmed_codes";
    $programmed_code_result = mysqli_query($conn, $programmed_code_query);

    if (mysqli_num_rows($programmed_code_result) > 0) {
        echo "<ul>";
        while ($programmed_code_row = mysqli_fetch_assoc($programmed_code_result)) {
            echo "<li>" . $programmed_code_row['code'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "No programmed codes found.";
    }
    ?>

    <!-- Display existing priorities -->
    <h2>Priorities</h2>
    <?php
    $priority_query = "SELECT * FROM priorities";
    $priority_result = mysqli_query($conn, $priority_query);

    if (mysqli_num_rows($priority_result) > 0) {
        echo "<ul>";
        while ($priority_row = mysqli_fetch_assoc($priority_result)) {
            echo "<li>" . $priority_row['label'] . "</li>";
        }
        echo "</ul>";
    } else {
        echo "No priorities found.";
    }
    ?>

<button onclick="window.location.href='edit_form.php'">Edit Page</button>
</div>



        <div id="manageUsersSection" class="tabcontent">
             <!-- Content for managing users -->
             <h2>Manage Users</h2>
             <?php
// Establish database connection
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "complaint"; 

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the delete button is clicked
if(isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];

    // Delete the user from the database
    $delete_sql = "DELETE FROM users WHERE id = $user_id";
    if (mysqli_query($conn, $delete_sql)) {
        echo "User deleted successfully.";
    } else {
        echo "Error deleting user: " . mysqli_error($conn);
    }
}

// Fetch users from the database
$sql = "SELECT * FROM users";
$result = mysqli_query($conn, $sql);

// Check if there are users
if (mysqli_num_rows($result) > 0) {
    // Display users in a table
    echo "<table>";
    echo "<tr><th>Username</th><th>Email</th><th>Number</th><th>Address</th><th>Action</th></tr>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['number'] . "</td>";
        echo "<td>" . $row['address'] . "</td>";
        echo "<td>";
        echo "<a href='delete_user.php?id=" . $row['id'] . "' class='delete-btn'>Delete</a>";     
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No users found.";
}

// Close database connection
mysqli_close($conn);
?>
</div>

<div class="content">
        
        <div id="adminGuide" class="tabcontent">
        <div class="video" style="text-align: center;">
      <iframe width="600" height="400" src="https://www.youtube.com/embed/6b7n3cS-lU0" frameborder="0"></iframe>
    </div>
        </div>
        </div>

    <script>
        // JavaScript to handle tabbed navigation
        function openPage(pageName, elmnt) {
            // Hide all content sections
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            // Remove the 'active' class from all tab links
            tablinks = document.getElementsByClassName("tablink");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }

            // Show the specific content section and mark the button as active
            document.getElementById(pageName).style.display = "block";
            elmnt.classList.add("active");
        }
        // JavaScript function to confirm deletion
        function confirmDelete(userId) {
    // Display alert to confirm deletion
    var confirmation = confirm('Are you sure you want to delete this account?');
    // If user confirms, submit the corresponding form
    if (confirmation) {
        document.getElementById('delete_form_' + userId).submit();
    }
}

        // By default, open the first tab
        document.getElementById("defaultOpen").click();
    </script>
</body>
</html>
