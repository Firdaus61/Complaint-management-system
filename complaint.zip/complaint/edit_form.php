<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Form</title>
    <!-- Add your CSS file here for styling -->
    <link rel="stylesheet" href="styles_edit_forms.css">
</head>
<body>
<div class="back">
        <button onclick="window.location.href='admin.php'">back</button>
    </div>
    <!-- Form for adding new Division/Unit -->
    <h2>Add New Division/Unit</h2>
    <form method="post">
        <label for="division_unit_name">Division/Unit Name:</label>
        <input type="text" id="division_unit_name" name="division_unit_name" required><br><br>
        <button type="submit" name="add_division_unit">Add Division/Unit</button>
    </form>

    <!-- Display existing Division/Units -->
    <h2>Division/Units</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Action</th>
        </tr>
        <?php
        
        $host = "localhost"; 
        $username = "root"; 
        $password = "";
        $database = "complaint"; 

        $conn = mysqli_connect($host, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Function to delete an item
        function deleteItem($conn, $table, $id) {
            $delete_query = "DELETE FROM $table WHERE id = $id";
            if (mysqli_query($conn, $delete_query)) {
                echo "Item deleted successfully";
            } else {
                echo "Error deleting item: " . mysqli_error($conn);
            }
        }

        // Check if delete button is clicked for Division/Unit and perform deletion
        if (isset($_POST['delete_division_unit']) && isset($_POST['division_unit_id'])) {
            $id = $_POST['division_unit_id'];
            deleteItem($conn, 'division_unit', $id);
        }

        // Fetch existing division/units from the database and display in the table rows
        $division_unit_query = "SELECT * FROM division_unit";
        $division_unit_result = mysqli_query($conn, $division_unit_query);

        while ($division_unit_row = mysqli_fetch_assoc($division_unit_result)) {
            echo "<tr>";
            echo "<td>" . $division_unit_row['name'] . "</td>";
            echo "<td>";
            echo "<form method='post'>";
            echo "<input type='hidden' name='division_unit_id' value='" . $division_unit_row['id'] . "'>";
            echo "<button type='submit' name='delete_division_unit'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }

        // Close result set
        mysqli_free_result($division_unit_result);
        ?>
    </table>

    <!-- Form for adding new Programmed Code -->
    <h2>Add New Programmed Code</h2>
    <form method="post">
        <label for="programmed_code">Programmed Code:</label>
        <input type="text" id="programmed_code" name="programmed_code" required><br><br>
        <button type="submit" name="add_programmed_code">Add Programmed Code</button>
    </form>

    <!-- Display existing Programmed Codes -->
    <h2>Programmed Codes</h2>
    <table>
        <tr>
            <th>Code</th>
            <th>Action</th>
        </tr>
        <?php
        // Check if delete button is clicked for Programmed Code and perform deletion
        if (isset($_POST['delete_programmed_code']) && isset($_POST['programmed_code_id'])) {
            $id = $_POST['programmed_code_id'];
            deleteItem($conn, 'programmed_codes', $id);
        }

        // Fetch existing programmed codes from the database and display in the table rows
        $programmed_code_query = "SELECT * FROM programmed_codes";
        $programmed_code_result = mysqli_query($conn, $programmed_code_query);

        while ($programmed_code_row = mysqli_fetch_assoc($programmed_code_result)) {
            echo "<tr>";
            echo "<td>" . $programmed_code_row['code'] . "</td>";
            echo "<td>";
            echo "<form method='post'>";
            echo "<input type='hidden' name='programmed_code_id' value='" . $programmed_code_row['id'] . "'>";
            echo "<button type='submit' name='delete_programmed_code'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }

        // Close result set
        mysqli_free_result($programmed_code_result);
        ?>
    </table>

    <!-- Form for setting Priority -->
    <h2>Add New Priority</h2>
<form method="post">
    <label for="priority">Priority:</label>
    <input type="text" id="priority" name="priority" required><br><br>
    <input type="hidden" name="set_priority"> <!-- Add this line -->
    <button type="submit" name="add_priority">Add Priority</button>
</form>

    <!-- Display existing Priorities -->
    <h2>Priorities</h2>
    <table>
        <tr>
            <th>Label</th>
            <th>Action</th>
        </tr>
        <?php
        // Check if delete button is clicked for Priority and perform deletion
        if (isset($_POST['delete_priority']) && isset($_POST['priority_id'])) {
            $id = $_POST['priority_id'];
            deleteItem($conn, 'priorities', $id);
        }

        // Fetch existing priorities from the database and display in the table rows
        $priority_query = "SELECT * FROM priorities";
        $priority_result = mysqli_query($conn, $priority_query);

        while ($priority_row = mysqli_fetch_assoc($priority_result)) {
            echo "<tr>";
            echo "<td>" . $priority_row['label'] . "</td>";
            echo "<td>";
            echo "<form method='post'>";
            echo "<input type='hidden' name='priority_id' value='" . $priority_row['id'] . "'>";
            echo "<button type='submit' name='delete_priority'>Delete</button>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }

        
        mysqli_free_result($priority_result);

        // Close database connection
        mysqli_close($conn);
        ?>
    </table>

   
    <?php
// Establish database connection
$host = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "complaint"; 

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Processing form submission
if(isset($_POST['add_division_unit'])) {
    $division_unit_name = $_POST['division_unit_name'];

    // Insert the new Division/Unit name into the database
    $insert_query = "INSERT INTO division_unit (name) VALUES ('$division_unit_name')";
    if (mysqli_query($conn, $insert_query)) {
        echo "Division/Unit added successfully.";
    } else {
        echo "Error adding Division/Unit: " . mysqli_error($conn);
    }
}

if(isset($_POST['add_programmed_code'])) {
    $programmed_code = $_POST['programmed_code'];

    // Insert the new programmed code into the database
    $insert_query = "INSERT INTO programmed_codes (code) VALUES ('$programmed_code')";
    if (mysqli_query($conn, $insert_query)) {
        echo "Programmed code added successfully.";
    } else {
        echo "Error adding programmed code: " . mysqli_error($conn);
    }
}

if(isset($_POST['set_priority'])) {
    $priority_label = $_POST['priority']; 

    // Insert the priority label into the database
    $insert_query = "INSERT INTO priorities (label) VALUES ('$priority_label')";
    if (mysqli_query($conn, $insert_query)) {
        echo "Priority set successfully.";
    } else {
        echo "Error setting priority: " . mysqli_error($conn);
    }
}
mysqli_close($conn);
    ?>
</body>
</html>
