<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles_index3.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="UPTM.png" alt="Admin Logo"> 
        </div>
        <div class="logout">
            <button onclick="window.location.href='signin.php'">logout</button>
        </div>
    </header>
    <nav>
        <button class="tablink" onclick="openPage('homePage', this)">Home Page</button>
        <button class="tablink" onclick="openPage('Complaint', this)">Complaint</button>
        <button class="tablink" onclick="openPage('Profile', this)">Profile</button>
        <button class="tablink" onclick="openPage('userManual', this)">User Manual</button>
    </nav>
    <div class="content">
        <div id="homePage" class="tabcontent">
            <h2>Welcome to Our Website</h2>
            <p>At Our Website, we are dedicated to providing exceptional service to our customers.</p>
            <h3>About Us</h3>
<p>Welcome to Our Website, your trusted platform for resolving student complaints effectively. In just three months, we've become an essential part of the student community, offering a reliable system for addressing concerns and improving the educational experience.</p>
<p>Our mission is simple: to bridge the gap between students and administrators by providing a user-friendly platform where complaints are heard and acted upon promptly. With our dedicated team and innovative approach, we've already made a significant impact in fostering a culture of transparency and accountability.</p>
<p>Join us on this journey as we continue to empower students and strengthen the relationship between educational institutions and their valued community members.</p>

            <h3>FAQs</h3>
        <div class="faq">
            <h4>How do I submit a complaint?</h4>
            <p>To submit a complaint, simply click on the "Submit a Complaint" button and fill out the complaint form with your details and the nature of your complaint.</p>
        </div>
        <div class="faq">
            <h4>How can I track my complaint?</h4>
            <p>Once you've submitted a complaint, you can track its status by logging into your account and visiting the Complaint section. You'll be able to see updates and any actions taken on your complaint.</p>
        </div>
        <div class="faq">
            <h4>What should I do if I have a question not addressed in the FAQs?</h4>
            <p>If you have any other questions or concerns, feel free to contact us directly through email or phone. Our customer support team will be happy to assist you.</p>
        </div>
        <div class="faq">
            <h4>Is my personal information secure?</h4>
            <p>Yes, we take the security and privacy of your personal information very seriously. Our website uses encryption and follows best practices to ensure that your data remains safe and confidential.</p>
        </div>
        <div class="faq">
            <h4>How long does it take to resolve a complaint?</h4>
            <p>The time taken to resolve a complaint may vary depending on the nature of the issue and the actions required. However, we strive to address all complaints as quickly as possible and keep you informed throughout the process.</p>
        </div>
            <h3>Contact Us</h3>
            <p>If you have any questions or concerns, please don't hesitate to contact us:</p>
            <p>Email: uptm123@gmail.com.my</p>
            <p>Phone: 123-456-7890</p>
            <a href="add_complaint.php" class="btn">Submit a Complaint</a>
        </div>
    </div>

    <div id="Complaint" class="tabcontent">
    <button onclick="window.location.href='add_complaint.php'" class="add-btn">Add Complaint</button>
            <!-- Display all complaints submitted by the user -->
            <?php
// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    // If not logged in, redirect to the sign-in page
    header("Location: signin.php?error=Please log in to view your complaints.");
    exit();
}

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$database = "complaint";

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch complaints associated with the logged-in user's email
$user_email = $_SESSION["email"];
$sql_complaints = "SELECT id, name, email, division_unit, subject, status FROM complaints WHERE email = '$user_email'";
$result_complaints = mysqli_query($conn, $sql_complaints);

// Check if there are complaints
if (mysqli_num_rows($result_complaints) > 0) {
    // Display complaints in a table
    echo "<h2>My Complaints</h2>";
    echo "<table>";
    echo "<tr><th>Name</th><th>Email</th><th>Division/Unit</th><th>Subject</th><th>Status</th><th>Admin Reply</th><th>Edit</th><th>Delete</th></tr>";
    while ($row = mysqli_fetch_assoc($result_complaints)) {
        echo "<tr>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "<td>" . $row['division_unit'] . "</td>";
        echo "<td>" . $row['subject'] . "</td>";
        echo "<td>" . $row['status'] . "</td>"; // Display status

       // Fetch admin reply for this complaint
$complaint_id = $row['id'];
$sql_admin_reply = "SELECT admin_reply FROM admin_replies WHERE complaint_id = '$complaint_id'";

$result_admin_reply = mysqli_query($conn, $sql_admin_reply);

echo "<td>";
if ($result_admin_reply) {
    if (mysqli_num_rows($result_admin_reply) > 0) {
        // Display admin reply
        $admin_reply_row = mysqli_fetch_assoc($result_admin_reply);
        echo $admin_reply_row['admin_reply'];
    } else {
        echo "No admin reply yet.";
    }
} else {
    echo "Error fetching admin reply: " . mysqli_error($conn);
}
echo "</td>";

        // Edit and delete buttons
        echo "<td>";
        echo "<a href='edit_complaint.php?id=" . $row['id'] . "' class='edit-btn'>Edit</a>";
        echo "</td>";
        echo "<td>";
        echo "<a href='delete_complaint.php?id=" . $row['id'] . "' class='delete-btn'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No complaints found.";
}

// Close database connection
mysqli_close($conn);
?>

        </div>
    </div>

    <div class="content">
        <div id="Profile" class="tabcontent">
        <button onclick="window.location.href='profile.php'">Edit Profile</button>
        <?php

// Check if the user is logged in
if (!isset($_SESSION["email"])) {
    // If not logged in, redirect to the sign-in page
    header("Location: signin.php?error=Please log in to view your profile.");
    exit();
}

// Database connection parameters
$host = "localhost";
$username = "root";
$password = "";
$database = "complaint";

// Create a connection to the database
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch user data based on the email stored in the session
$user_email = $_SESSION["email"];
$sql = "SELECT * FROM users WHERE email = '$user_email'";
$result = mysqli_query($conn, $sql);

// Check if user data exists
if (mysqli_num_rows($result) > 0) {
    // Fetch user information
    $row = mysqli_fetch_assoc($result);
    $username = $row["username"];
    $email = $row["email"];
    $number = $row["number"];
    $address = $row["address"];

    // Close the database connection
    mysqli_close($conn);
} else {
    // If no user data found, display an error message
    $username = "Unknown";
    $email = "Unknown";
    $number = "Unknown";
    $address = "Unknown";
}
?>
      <div class="profile-card">
            <h1>User Profile</h1>
            <div class="profile-info">
                <p><strong>Username:</strong> <?php echo $username; ?></p>
                <p><strong>Email:</strong> <?php echo $email; ?></p>
                <p><strong>Phone Number:</strong> <?php echo $number; ?></p>
                <p><strong>Address:</strong> <?php echo $address; ?></p>
            </div>
        </div>
    </div>
</div>

<div class="content">
        
        <div id="userManual" class="tabcontent">
        <div class="video" style="text-align: center;">
      <iframe width="600" height="400" src="https://www.youtube.com/embed/5tEBf10o1kg" frameborder="0"></iframe>
    </div>
        </div>
        </div>

    <script>
        // JavaScript to handle tabbed navigation
        function openPage(pageName, elmnt) {
            // Hide all content sections
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tabcontent");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
            }

            // Remove the 'active' class from all tab links
            tablinks = document.getElementsByClassName("tablink");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }

            // Show the specific content section and mark the button as active
            document.getElementById(pageName).style.display = "block";
            elmnt.classList.add("active");
        }

        // By default, open the Home Page tab
        document.getElementById("homePage").click();
    </script>
</body>
</html>
