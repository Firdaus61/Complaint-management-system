
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>
    <div class="container">
        <h2>User Registration</h2>
        <form action="signup1.php" method="post">
            <div class="error"><?php if(isset($_GET['error'])) echo $_GET['error']; ?></div>
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required> 
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <input type="text" name="number" placeholder="Phone Number">
            <select name="address" id="address">
                <option value="Mr.">Mr.</option>
                <option value="Ms.">Ms.</option>
                <option value="Mrs.">Mrs.</option>
                <option value="Dr.">Dr.</option>
                <option value="Prof.">Prof.</option>
                <option value="Other">Other</option>
            </select>
            <!-- Add an input field for "Other" address -->
            <input type="text" name="other_address" id="other_address" placeholder="" style="display: none;">

            <input type="submit" name="signup-submit" value="Sign Up">
        </form>
        <p>Already have an account? <a href="signin.php">Sign In</a></p>
    </div>
    <script>
document.getElementById('address').addEventListener('change', function() {
    var otherAddressInput = document.getElementById('other_address');
    if (this.value === 'Other') {
        otherAddressInput.style.display = 'block';
        otherAddressInput.setAttribute('required', 'required');
    } else {
        otherAddressInput.style.display = 'none';
        otherAddressInput.removeAttribute('required');
    }
});
</script>

</body>
</html>
